ΟΔΗΓΙΕΣ ΓΙΑ GITHUB PAGES

1. Δημιούργησε λογαριασμό στο github.com.
2. Πάτα New repository.
3. Όνομα repository: infinity-groups
4. Βάλε Public.
5. Πάτα Create repository.
6. Κάνε Upload το αρχείο index.html.
7. Πήγαινε Settings > Pages.
8. Στο Branch διάλεξε main και /root.
9. Πάτα Save.
10. Σε 1-2 λεπτά θα έχεις online link τύπου:
   https://TO-USERNAME-SOU.github.io/infinity-groups/

Σημαντικό:
Αυτή η έκδοση εμφανίζεται online και ανοίγει από όλους.
Για πραγματικό live editing από πολλούς συνεργάτες ταυτόχρονα χρειάζεται επόμενο βήμα:
online booking system με database.
